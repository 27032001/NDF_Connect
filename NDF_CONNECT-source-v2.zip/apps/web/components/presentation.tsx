"use client";

import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import "./presentation.css";

type Page = "Vue d’ensemble" | "Mes dépenses" | "Coffre-fort" | "Ma checklist" | "Connexions" | "Mon profil";
type IconName = "grid" | "wallet" | "folder" | "check" | "link" | "arrow" | "plus" | "bell" | "search" | "down" | "file" | "train" | "food" | "bag" | "shield" | "globe" | "close" | "download" | "clock" | "user";
const paths: Record<IconName, ReactNode> = {
  grid: <><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></>,
  wallet: <><path d="M20 7H5a2 2 0 0 1 0-4h13v4M3 5v14a2 2 0 0 0 2 2h15V7M20 11h-5v6h5"/><path d="M17 14h.01"/></>,
  folder: <path d="M3 7V4h7l3 3h8v13H3V7Z"/>,
  check: <><rect x="3" y="3" width="18" height="18" rx="5"/><path d="m7 12 3 3 7-7"/></>,
  link: <path d="m10 14 4-4M8 15l-1 1a3 3 0 0 1-4-4l4-4a3 3 0 0 1 4 0M16 9l1-1a3 3 0 0 0-4-4l-4 4M13 16a3 3 0 0 0 4 0l4-4a3 3 0 0 0-4-4"/>,
  arrow: <path d="M4 12h16m-6-6 6 6-6 6"/>,
  plus: <path d="M12 5v14M5 12h14"/>,
  bell: <path d="M5 17h14l-2-3V9a5 5 0 0 0-10 0v5l-2 3ZM10 21h4"/>,
  search: <><circle cx="10" cy="10" r="6"/><path d="m15 15 5 5"/></>,
  down: <path d="m6 9 6 6 6-6"/>,
  file: <path d="M14 3H5v18h14V8l-5-5Zm0 0v6h5M8 13h8M8 17h5"/>,
  train: <><rect x="5" y="3" width="14" height="15" rx="4"/><path d="M5 10h14M9 3v7M15 3v7M8 21l2-3m6 3-2-3M8 14h1m6 0h1"/></>,
  food: <path d="M5 3v7h6V3M8 3v18M19 3c-4 4-4 9 0 9V3Zm0 9v9"/>,
  bag: <path d="M4 8h16l-1 13H5L4 8ZM8 8V6a4 4 0 0 1 8 0v2"/>,
  shield: <><path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Z"/><path d="m8 12 3 3 5-6"/></>,
  globe: <><circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/></>,
  close: <path d="m6 6 12 12M18 6 6 18"/>,
  download: <path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>,
  clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
  user: <><circle cx="12" cy="7" r="4"/><path d="M4 21v-3a8 8 0 0 1 16 0v3"/></>,
};
function Icon({ name, size = 20 }: { name: IconName; size?: number }) { return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>; }
type Expense = { id: number; merchant: string; detail: string; date: string; amount: number; category: string; receipt: boolean };
const initialExpenses: Expense[] = [
  { id: 1, merchant: "SNCF Connect", detail: "Paris → Lyon · déplacement école", date: "2026-09-14", amount: 86, category: "Transport", receipt: true },
  { id: 2, merchant: "Boulangerie Paul", detail: "Déjeuner · journée en entreprise", date: "2026-09-14", amount: 14.5, category: "Repas", receipt: true },
  { id: 3, merchant: "Fnac", detail: "Clavier · équipement de travail", date: "2026-09-12", amount: 79.99, category: "Matériel", receipt: false },
  { id: 4, merchant: "Navigo", detail: "Abonnement mensuel · Île-de-France", date: "2026-09-01", amount: 88.8, category: "Transport", receipt: true },
];
const initialDocuments = [
  { name: "Passeport", category: "Identité", expiry: "12 juin 2030", state: "Valide", present: true },
  { name: "Titre de séjour", category: "Séjour", expiry: "28 octobre 2026", state: "À renouveler", present: true },
  { name: "Contrat d’apprentissage", category: "Alternance", expiry: "31 août 2027", state: "Valide", present: true },
  { name: "Certificat de scolarité", category: "Études", expiry: "Année 2026–2027", state: "Manquant", present: false },
  { name: "RIB", category: "Finances", expiry: "Sans expiration", state: "Valide", present: true },
  { name: "Justificatif de domicile", category: "Logement", expiry: "Moins de 3 mois", state: "Manquant", present: false },
];
const navigation: { label: Page; icon: IconName }[] = [{ label: "Vue d’ensemble", icon: "grid" }, { label: "Mes dépenses", icon: "wallet" }, { label: "Coffre-fort", icon: "folder" }, { label: "Ma checklist", icon: "check" }, { label: "Connexions", icon: "link" }];
const euro = (amount: number) => amount.toLocaleString("fr-FR", { style: "currency", currency: "EUR" });

export function Presentation() {
  const [page, setPage] = useState<Page>("Vue d’ensemble");
  const [expenses, setExpenses] = useState(initialExpenses);
  const [documents, setDocuments] = useState(initialDocuments);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Tout");
  const [modal, setModal] = useState<"expense" | "document" | "notification" | "category" | null>(null);
  const [toast, setToast] = useState("");
  const [name, setName] = useState("Xavier");
  const [country, setCountry] = useState("Gabon");
  const [selectedDoc, setSelectedDoc] = useState("Certificat de scolarité");
  const [vaultCategories, setVaultCategories] = useState([...initialDocuments.map((doc) => doc.category), "Autre"]);
  const [vaultFilter, setVaultFilter] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Études");
  const [extraDocuments, setExtraDocuments] = useState<typeof initialDocuments>([]);
  const [formError, setFormError] = useState("");
  const vaultDocuments = [...documents, ...extraDocuments];
  const displayedDocuments = vaultDocuments.filter((doc) => !vaultFilter || doc.category === vaultFilter);
  const [selectedExpense, setSelectedExpense] = useState<Expense | null>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const opener = useRef<HTMLElement | null>(null);
  const visible = expenses.filter((item) => (category === "Tout" || item.category === category) && (item.merchant + " " + item.detail).toLowerCase().includes(query.toLowerCase()));
  const total = expenses.reduce((sum, item) => sum + item.amount, 0);
  const count = documents.filter((doc) => doc.present).length;
  const score = Math.round(count / documents.length * 100);
  const expiring = documents.filter((doc) => doc.state === "À renouveler").length;
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(""), 3800); return () => clearTimeout(timer); }, [toast]);
  useEffect(() => {
    if (modal || selectedExpense) { if (!dialogRef.current?.open) opener.current = document.activeElement as HTMLElement; dialogRef.current?.showModal(); }
    else { dialogRef.current?.close(); opener.current?.focus(); }
  }, [modal, selectedExpense]);
  function navigate(next: Page) { setPage(next); setQuery(""); setCategory("Tout"); }
  function closeModal() { setModal(null); setSelectedExpense(null); setFormError(""); }
  function addExpense(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const data = new FormData(event.currentTarget); const file = data.get("receipt") as File;
    setExpenses([{ id: Date.now(), merchant: String(data.get("merchant")), detail: String(data.get("description") || "Dépense de démonstration"), amount: Number(data.get("amount")), category: String(data.get("category")), date: String(data.get("date")), receipt: Boolean(file?.size) }, ...expenses]);
    closeModal(); setToast("Votre dépense a été ajoutée à la démo.");
  }
  function exportExpenses() {
    const csv = "\uFEFF" + ["Commerçant;Date;Catégorie;Montant EUR;Justificatif", ...expenses.map((item) => [item.merchant, item.date, item.category, item.amount.toFixed(2).replace(".", ","), item.receipt ? "Présent" : "Manquant"].map((v) => '"' + String(v).replace(/"/g, '""') + '"').join(";"))].join("\r\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" })); const anchor = document.createElement("a"); anchor.href = url; anchor.download = "ndf-connect-depenses-demo.csv"; anchor.click(); URL.revokeObjectURL(url); setToast("Le récapitulatif CSV a été téléchargé.");
  }
  function expenseTable(compact = false) { return <div className="expense-table-wrap"><table className="expense-table"><thead><tr><th>DÉPENSE</th><th>CATÉGORIE</th><th>JUSTIFICATIF</th><th>MONTANT</th><th><span className="sr-only">Détail</span></th></tr></thead><tbody>{(compact ? expenses.slice(0, 4) : visible).map((item) => <tr key={item.id}><td><div className="merchant-cell"><span className={"merchant-icon " + item.category.toLowerCase()}><Icon name={item.category === "Transport" ? "train" : item.category === "Repas" ? "food" : "bag"}/></span><span><strong>{item.merchant}</strong><small>{new Date(item.date + "T12:00:00").toLocaleDateString("fr-FR", { day: "numeric", month: "short" })} · {item.detail.split(" · ")[0]}</small></span></div></td><td><span className="category-tag">{item.category}</span></td><td><span className={"status-tag " + (item.receipt ? "good" : "warning")}><span className="status-dot"/>{item.receipt ? "Ajouté" : "À ajouter"}</span></td><td className="amount">{euro(item.amount)}</td><td><button className="row-action" aria-label={"Voir " + item.merchant} onClick={() => setSelectedExpense(item)}><Icon name="arrow" size={17}/></button></td></tr>)}</tbody></table>{!compact && visible.length === 0 && <div className="empty-state">Aucune dépense ne correspond à votre recherche.</div>}</div>; }
  function openDocument(docName: string) {
    setSelectedDoc(docName);
    setSelectedCategory(vaultDocuments.find((doc) => doc.name === docName)?.category ?? (vaultFilter || "Autre"));
    setFormError("");
    setModal("document");
  }
  function addCategory(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const value = String(new FormData(event.currentTarget).get("category_name") ?? "").trim().replace(/\s+/g, " ");
    if (!value) { setFormError("Donnez un nom à votre catégorie."); return; }
    if (vaultCategories.some((item) => item.localeCompare(value, "fr", { sensitivity: "base" }) === 0)) {
      setFormError("Cette catégorie existe déjà. Choisissez un autre nom."); return;
    }
    setVaultCategories([...vaultCategories, value]);
    setVaultFilter(value);
    closeModal();
    setToast("Catégorie « " + value + " » créée. Vous pouvez y ajouter des documents.");
  }
  function saveDocument(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const isNew = selectedDoc === "__new__";
    const docName = isNew ? String(data.get("title") ?? "").trim() : selectedDoc;
    if (!docName) { setFormError("Donnez un titre à votre document."); return; }
    if (isNew && vaultDocuments.some((doc) => doc.name.localeCompare(docName, "fr", { sensitivity: "base" }) === 0)) {
      setFormError("Un document porte déjà ce titre."); return;
    }
    const upload = data.get("file") as File | null;
    const existing = vaultDocuments.find((doc) => doc.name === selectedDoc);
    if ((isNew || !existing?.present) && !upload?.size) {
      setFormError("Sélectionnez un fichier pour ajouter ce document."); return;
    }
    if (isNew) {
      setExtraDocuments([...extraDocuments, { name: docName, category: selectedCategory, expiry: "Sans expiration", state: "Valide", present: true }]);
    } else {
      const update = (doc: typeof initialDocuments[number]) => doc.name !== selectedDoc ? doc : {
        ...doc, category: selectedCategory,
        ...(upload?.size ? { present: true, state: "Valide", expiry: doc.name === "Titre de séjour" ? "28 octobre 2027" : doc.expiry } : {}),
      };
      setDocuments(documents.map(update));
      setExtraDocuments(extraDocuments.map(update));
    }
    if (page === "Coffre-fort") setVaultFilter(selectedCategory);
    closeModal();
    setToast(isNew ? "Votre document a été ajouté à la catégorie « " + selectedCategory + " »." : "Votre document a été mis à jour.");
  }

  return <div className="demo-app">
    <aside className="sidebar">
      <button className="demo-brand" onClick={() => navigate("Vue d’ensemble")} aria-label="NDF Connect, accueil"><span className="logo-glyph">n<span>↗</span></span><span>ndf<span className="brand-connect">connect</span></span></button>
      <div className="workspace-label"><span className="workspace-icon"><Icon name="user" size={16}/></span><span>Espace personnel<small>Tout commence ici</small></span><Icon name="down" size={14}/></div>
      <p className="nav-caption">MON QUOTIDIEN</p>
      <nav aria-label="Navigation principale">{navigation.map((item) => <button key={item.label} className={"nav-item " + (page === item.label ? "selected" : "")} onClick={() => navigate(item.label)} aria-current={page === item.label ? "page" : undefined}><Icon name={item.icon}/><span>{item.label}</span>{item.label === "Ma checklist" && <span className="nav-count">{documents.length - count}</span>}{item.label === "Connexions" && <span className="soon-dot"/>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="journey-card"><span className="journey-icon"><Icon name="globe" size={24}/></span><h3>Un nouveau pays.<br/>Les bons repères.</h3><p>On vous accompagne,<br/>une démarche à la fois.</p><button onClick={() => navigate("Ma checklist")}>Mon parcours <Icon name="arrow" size={16}/></button><span className="journey-orbit"/></div><button className="profile-switch" onClick={() => navigate("Mon profil")}><span className="avatar">{name.charAt(0)}O</span><span><strong>{name} Ogandaga</strong><small>Étudiant en alternance</small></span><Icon name="down" size={14}/></button></div>
    </aside>
    <div className="main-area">
      <header className="demo-topbar"><div className="breadcrumb">Mon espace <span>/</span> <strong>{page}</strong></div><div className="topbar-actions"><button className="notification-button" aria-label="Voir les notifications" onClick={() => setModal("notification")}><Icon name="bell"/><i/></button><button className="avatar small-avatar" aria-label="Mon profil" onClick={() => navigate("Mon profil")}>{name.charAt(0)}O</button></div></header>
      <main className="demo-content">
        <div className="page-intro"><div><p className="section-kicker">{page === "Vue d’ensemble" ? "TOUT EST À SA PLACE" : "VOTRE ESPACE PERSONNEL"}</p><h1>{page === "Vue d’ensemble" ? <>Bonjour {name}<span className="hello-spark">✳</span></> : page}</h1><p className="intro-subtitle">{{ "Vue d’ensemble": "Moins de paperasse. Plus de place pour vos projets.", "Mes dépenses": "Chaque dépense à sa place, chaque justificatif à portée de main.", "Coffre-fort": "Vos documents importants, réunis dans un seul espace.", "Ma checklist": "Un parcours qui s’adapte à votre situation.", "Connexions": "Votre espace, connecté à vos outils du quotidien.", "Mon profil": "Quelques informations pour mieux vous accompagner." }[page]}</p></div><div className="intro-actions">{page === "Vue d’ensemble" && <span className="date-label"><Icon name="clock" size={15}/> Mardi 15 septembre 2026</span>}{["Vue d’ensemble", "Mes dépenses"].includes(page) && <button className="demo-primary" onClick={() => setModal("expense")}><Icon name="plus" size={18}/> Nouvelle dépense</button>}{page === "Coffre-fort" && <div className="vault-header-actions"><button className="demo-secondary" onClick={() => { setFormError(""); setModal("category"); }}><Icon name="folder" size={17}/> Nouvelle catégorie</button><button className="demo-primary" onClick={() => openDocument("__new__")}><Icon name="plus" size={18}/> Ajouter un document</button></div>}</div></div>

        {page === "Vue d’ensemble" && <>
          <section className="welcome-banner"><div className="welcome-copy"><span className="banner-tag"><span className="flag-gabon"/> DU {country.toUpperCase()} À LA FRANCE</span><h2>Votre avenir avance.<br/>Votre administratif aussi.</h2><p>Dépenses, documents, démarches :<br/>gardez l’esprit libre, on fait le lien.</p><button onClick={() => navigate("Ma checklist")}>Découvrir mon parcours <Icon name="arrow" size={17}/></button></div><div className="banner-art" aria-hidden="true"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><span className="art-spark">✳</span><div className="floating-note note-back"><span className="note-icon"><Icon name="wallet" size={22}/></span><span>Note de frais<strong>Tout est en ordre.</strong></span><span className="mini-check">✓</span></div><div className="floating-note note-front"><div className="document-illustration"><Icon name="file" size={30}/></div><div><span>MON DOSSIER</span><strong>Un pas de plus<br/>vers vos projets.</strong><div className="illustration-progress"><i/></div></div></div><span className="art-seal"><Icon name="shield" size={25}/></span><span className="art-dot"/></div></section>
          <section className="stat-grid" aria-label="Votre situation en un coup d’œil"><article className="stat-card"><div className="stat-top"><span>Dépenses du mois</span><span className="stat-symbol"><Icon name="wallet"/></span></div><strong>{euro(total)}</strong><p><span className="teal-text">{expenses.length} dépenses</span><span>Septembre 2026</span></p><div className="mini-bars" aria-hidden="true">{[28,45,31,60,44,75,50,89,66,55,83,100,63,78].map((height,i) => <i key={i} style={{height:height + "%"}}/>)}</div></article><article className="stat-card"><div className="stat-top"><span>Dossier administratif</span><span className="stat-symbol"><Icon name="check"/></span></div><div className="score-line"><strong>{score}<small>%</small></strong><span className="status-tag good">{score === 100 ? "Complet" : "Bien avancé"}</span></div><div className="stat-progress"><i style={{width:score + "%"}}/></div><p><span>{count} documents sur {documents.length}</span><button onClick={() => navigate("Ma checklist")}>Compléter <Icon name="arrow" size={14}/></button></p></article><article className="stat-card"><div className="stat-top"><span>Documents à surveiller</span><span className="stat-symbol peach"><Icon name="clock"/></span></div><strong>{String(expiring).padStart(2,"0")}<span className="stat-unit">document</span></strong><p className="deadline-note"><span className="status-dot"/>{expiring ? "Votre titre de séjour expire dans 43 jours" : "Aucune échéance proche"}</p><button className="text-action" onClick={() => navigate("Coffre-fort")}>Voir les documents <Icon name="arrow" size={14}/></button></article></section>
          <div className="dashboard-columns"><section className="demo-panel recent-panel"><div className="panel-heading"><div><h2>Dernières dépenses</h2><p>Un œil sur vos derniers mouvements.</p></div><button className="text-action" onClick={() => navigate("Mes dépenses")}>Tout voir <Icon name="arrow" size={15}/></button></div>{expenseTable(true)}<div className="table-footer"><Icon name="shield" size={14}/><span>Vos justificatifs vous suivent, partout.</span></div></section><section className="demo-panel priorities-panel"><div className="panel-heading"><div><h2>À ne pas oublier</h2><p>Les petits pas qui font avancer.</p></div><span className="count-bubble">{documents.length - count + expiring}</span></div>{expiring > 0 && <button className="priority-item" onClick={() => openDocument("Titre de séjour")}><span className="priority-icon peach"><Icon name="clock" size={19}/></span><span><strong>Renouveler votre titre</strong><small>Avant le 28 octobre 2026</small><em>À anticiper</em></span><Icon name="arrow" size={15}/></button>}{documents.filter((doc) => !doc.present).slice(0, 2).map((doc) => <button className="priority-item" key={doc.name} onClick={() => openDocument(doc.name)}><span className="priority-icon"><Icon name="file" size={19}/></span><span><strong>{doc.name}</strong><small>À ajouter à votre dossier</small></span><Icon name="plus" size={16}/></button>)}<div className="priority-footnote"><span>✦</span> Chaque document ajouté, l’esprit plus léger.</div></section></div>
          <button className="connect-strip" onClick={() => navigate("Connexions")}><span className="connection-logos"><span>G</span><span className="microsoft-logo"><i/><i/><i/><i/></span></span><span><strong>Vos outils préférés, bientôt réunis.</strong><small>Connectez vos e-mails, votre Drive et votre calendrier.</small></span><span className="strip-link">Explorer les connexions <Icon name="arrow" size={17}/></span></button>
        </>}

        {page === "Mes dépenses" && <section className="demo-panel expenses-full"><div className="expense-summary"><div><span>SEPTEMBRE 2026</span><strong>{euro(total)}</strong><small>{expenses.length} dépenses · {expenses.filter((e) => !e.receipt).length} justificatif(s) manquant(s)</small></div><button className="demo-secondary" onClick={exportExpenses}><Icon name="download" size={17}/> Exporter le récapitulatif</button></div><div className="table-toolbar"><label className="search-field"><Icon name="search" size={17}/><input aria-label="Rechercher une dépense" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Rechercher une dépense…"/></label><div className="filter-tabs">{["Tout","Transport","Repas","Matériel","Autre"].map((value) => <button key={value} onClick={() => setCategory(value)} className={value === category ? "active" : ""}>{value}</button>)}</div></div>{expenseTable()}</section>}

        {page === "Coffre-fort" && <><div className="vault-notice"><span className="priority-icon"><Icon name="shield"/></span><span><strong>Votre essentiel mérite sa place.</strong><p>{vaultDocuments.filter((doc) => doc.present).length} documents dans votre coffre-fort de démonstration.</p></span><span className="status-tag good">Espace personnel</span></div><div className="vault-category-toolbar"><div className="vault-category-filters" role="group" aria-label="Filtrer par catégorie"><button className={!vaultFilter ? "active" : ""} aria-pressed={!vaultFilter} onClick={() => setVaultFilter("")}>Tous les documents <span>{vaultDocuments.length}</span></button>{vaultCategories.map((item) => <button key={item} title={item} className={vaultFilter === item ? "active" : ""} aria-pressed={vaultFilter === item} onClick={() => setVaultFilter(item)}>{item}<span>{vaultDocuments.filter((doc) => doc.category === item).length}</span></button>)}</div></div>{displayedDocuments.length === 0 && <div className="vault-empty"><span className="document-icon"><Icon name="folder" size={30}/></span><h2>{vaultFilter || "Votre coffre-fort"}</h2><p>Cette catégorie attend ses premiers documents.</p><button className="demo-primary" onClick={() => openDocument("__new__")}><Icon name="plus" size={17}/> Ajouter un document ici</button></div>}<div className="document-grid">{displayedDocuments.map((doc) => <article className={"document-card " + (!doc.present ? "missing-document" : "")} key={doc.name}><div className="document-top"><span className={"document-icon " + (doc.state === "À renouveler" ? "peach" : "")}><Icon name="file" size={26}/></span><span className={"status-tag " + (!doc.present || doc.state === "À renouveler" ? "warning" : "good")}>{doc.state}</span></div><span className="section-kicker">{doc.category}</span><h2>{doc.name}</h2><p><Icon name="clock" size={14}/>{doc.expiry}</p><button className="document-action" onClick={() => openDocument(doc.name)}>{doc.present ? "Gérer le document" : "Ajouter le document"}<Icon name={doc.present ? "arrow" : "plus"} size={17}/></button></article>)}</div></>}

        {page === "Ma checklist" && <><section className="checklist-hero"><div><span className="banner-tag">VOTRE PARCOURS INTERNATIONAL</span><h2>Votre prochain chapitre<br/>commence bien.</h2><p>{country} → France · Étudiant en alternance</p><span className="demo-rule">Règles de démonstration · à vérifier auprès des organismes officiels</span></div><div className="progress-ring" style={{background:"conic-gradient(#c9e7aa " + score + "%, #3f6459 0)"}}><div><strong>{score}%</strong><span>de votre dossier prêt</span></div></div></section><section className="demo-panel checklist-list"><div className="panel-heading"><div><h2>Les pièces de votre dossier</h2><p>{count} documents présents sur {documents.length}. Les documents bientôt expirés restent comptabilisés.</p></div></div>{documents.map((doc, i) => <div className="checklist-row" key={doc.name}><span className={"check-circle " + (doc.present ? "done" : "")}>{doc.present ? "✓" : String(i + 1).padStart(2,"0")}</span><div><strong>{doc.name}</strong><small>{doc.category} · {doc.expiry}</small></div><span className={"status-tag " + (!doc.present || doc.state === "À renouveler" ? "warning" : "good")}>{doc.state}</span><button className="row-action" aria-label={"Gérer " + doc.name} onClick={() => openDocument(doc.name)}><Icon name={doc.present ? "arrow" : "plus"} size={18}/></button></div>)}</section><p className="legal-note">Cette checklist illustre le produit. Elle ne constitue pas un avis juridique ni une liste officielle des démarches.</p></>}

        {page === "Connexions" && <><div className="connections-intro"><span className="connection-orbit"><Icon name="link" size={36}/></span><h2>Moins d’allers-retours.<br/>Plus de connexions.</h2><p>Imaginez : un justificatif reçu par e-mail, une dépense prête à être classée.</p><span className="status-tag">Aperçu des futures intégrations</span></div><div className="integration-grid">{[{name:"Google Workspace",mark:"G",copy:"Gmail, Google Drive et Google Agenda",items:["Retrouver vos justificatifs dans Gmail","Archiver vos exports dans Drive","Retrouver vos échéances dans Agenda"]},{name:"Microsoft 365",mark:"▦",copy:"Outlook, OneDrive et Calendar",items:["Préparer un brouillon dans Outlook","Classer vos documents dans OneDrive","Suivre les dates à ne pas oublier"]}].map((service) => <article className="demo-panel integration-card" key={service.name}><span className="service-mark">{service.mark}</span><h2>{service.name}</h2><p>{service.copy}</p><ul>{service.items.map((text) => <li key={text}><Icon name="check" size={17}/>{text}</li>)}</ul><button className="demo-secondary" onClick={() => setToast(service.name + " : intégration prévue, aucun compte connecté dans cette démo.")}>Découvrir l’intégration <Icon name="arrow" size={16}/></button></article>)}</div></>}

        {page === "Mon profil" && <form className="demo-panel demo-profile" onSubmit={(event) => {event.preventDefault(); const data = new FormData(event.currentTarget); setName(String(data.get("first_name"))); setCountry(String(data.get("country"))); setToast("Votre profil de démonstration a été mis à jour.");}}><div className="profile-cover"/><div className="profile-heading"><span className="avatar large-avatar">{name.charAt(0)}O</span><div><h2>{name} Ogandaga</h2><p>Étudiant en alternance · Paris, France</p></div><span className="status-tag good">Profil de démonstration</span></div><div className="demo-form-grid"><label>Prénom<input name="first_name" defaultValue={name} required maxLength={40}/></label><label>Nom<input defaultValue="Ogandaga" readOnly/></label><label>Adresse e-mail<input defaultValue="xavier.ogandaga@example.com" readOnly/></label><label>Pays de provenance<select name="country" defaultValue={country}><option>Gabon</option><option>Sénégal</option><option>Cameroun</option><option>Maroc</option><option>France</option></select></label><label>Situation<input value="Étudiant en alternance" readOnly/></label><label>Document de séjour<input value="Titre de séjour étudiant" readOnly/></label><div className="form-full"><button className="demo-primary" type="submit">Enregistrer les modifications <Icon name="check" size={17}/></button></div></div></form>}
        <footer className="demo-footer"><span>Fait pour avancer, ensemble.</span><span><span className="footer-dot"/> NDF CONNECT <span>·</span> Données de démonstration</span></footer>
      </main>
    </div>

    <dialog ref={dialogRef} className="demo-dialog" aria-labelledby="dialog-title" onCancel={closeModal} onClick={(e) => {if(e.target === e.currentTarget) closeModal();}}><div className="dialog-header"><span className="section-kicker">NDF CONNECT</span><button className="row-action" onClick={closeModal} aria-label="Fermer"><Icon name="close"/></button></div>
      {modal === "expense" && <><h2 id="dialog-title">Une nouvelle dépense.</h2><p>Ajoutez-la à votre espace de démonstration.</p><form className="demo-form-grid" onSubmit={addExpense}><label className="form-full">Commerçant<input name="merchant" required placeholder="Ex. SNCF Connect" maxLength={80}/></label><label>Montant (€)<input name="amount" type="number" min="0.01" max="999999" step="0.01" required placeholder="0,00"/></label><label>Date<input name="date" type="date" defaultValue="2026-09-15" min="2026-09-01" max="2026-09-30" required/></label><label className="form-full">Catégorie<select name="category"><option>Transport</option><option>Repas</option><option>Matériel</option><option>Autre</option></select></label><label className="form-full">Description<input name="description" placeholder="À quoi correspond cette dépense ?" maxLength={120}/></label><label className="file-drop form-full"><Icon name="file"/> Joindre un justificatif<input name="receipt" type="file" accept="image/*,.pdf"/><small>Démo locale : le fichier n’est pas envoyé à un serveur.</small></label><button type="submit" className="demo-primary form-full">Ajouter la dépense <Icon name="plus" size={17}/></button></form></>}
      {modal === "category" && <><h2 id="dialog-title">Une catégorie à votre image.</h2><p>Organisez votre coffre-fort comme vous le souhaitez.</p><form className="demo-form-grid" onSubmit={addCategory}><label className="form-full">Nom de la catégorie<input name="category_name" required maxLength={40} placeholder="Ex. Santé, Assurances, Projets…" onChange={() => setFormError("")}/></label>{formError && <p className="vault-form-error form-full" role="alert">{formError}</p>}<button type="submit" className="demo-primary form-full">Créer la catégorie <Icon name="plus" size={17}/></button></form></>}
      {modal === "document" && <><h2 id="dialog-title">{selectedDoc === "__new__" ? "Un nouveau document." : "Votre document, à sa place."}</h2><p>Choisissez sa catégorie pour le retrouver facilement.</p><form className="demo-form-grid" onSubmit={saveDocument}><label className="form-full">Type de document<select name="document" value={selectedDoc} onChange={(event) => { setSelectedDoc(event.target.value); setSelectedCategory(vaultDocuments.find((doc) => doc.name === event.target.value)?.category ?? (vaultFilter || "Autre")); setFormError(""); }}><option value="__new__">Nouveau document personnalisé</option>{vaultDocuments.map((doc) => <option key={doc.name}>{doc.name}</option>)}</select></label>{selectedDoc === "__new__" && <label className="form-full">Titre du document<input name="title" required maxLength={100} placeholder="Ex. Attestation d’assurance" onChange={() => setFormError("")}/></label>}<label className="form-full">Catégorie<select name="document_category" value={selectedCategory} onChange={(event) => setSelectedCategory(event.target.value)}>{vaultCategories.map((item) => <option key={item}>{item}</option>)}</select></label><label className="file-drop form-full"><Icon name="folder" size={28}/>{vaultDocuments.find((doc) => doc.name === selectedDoc)?.present ? "Remplacer le fichier (facultatif)" : "Sélectionner un fichier"}<input name="file" type="file" accept="image/*,.pdf" required={selectedDoc === "__new__" || !vaultDocuments.find((doc) => doc.name === selectedDoc)?.present}/><small>Démo locale : fichier non conservé. Un document existant peut être reclassé sans nouveau fichier.</small></label>{formError && <p className="vault-form-error form-full" role="alert">{formError}</p>}<button type="submit" className="demo-primary form-full">{selectedDoc === "__new__" || !vaultDocuments.find((doc) => doc.name === selectedDoc)?.present ? "Ajouter au coffre-fort" : "Enregistrer les modifications"}<Icon name="check" size={17}/></button></form></>}
      {modal === "notification" && <><h2 id="dialog-title">Vos rappels</h2><p>Un peu d’anticipation, beaucoup de sérénité.</p>{expiring > 0 && <div className="notification-card"><Icon name="clock"/><div><strong>Votre titre de séjour expire bientôt</strong><p>Échéance du dossier de démonstration : 28 octobre 2026.</p></div></div>}<div className="notification-card"><Icon name="file"/><div><strong>{documents.length - count} document(s) à ajouter</strong><p>Retrouvez les pièces manquantes dans votre checklist.</p></div></div><button className="demo-primary" onClick={() => {closeModal(); navigate("Ma checklist");}}>Ouvrir ma checklist <Icon name="arrow" size={17}/></button></>}
      {selectedExpense && <><h2 id="dialog-title">{selectedExpense.merchant}</h2><p>{selectedExpense.detail}</p><strong className="detail-amount">{euro(selectedExpense.amount)}</strong><div className="detail-row"><span>Catégorie</span><strong>{selectedExpense.category}</strong></div><div className="detail-row"><span>Date</span><strong>{selectedExpense.date}</strong></div><div className="detail-row"><span>Justificatif</span><span className={"status-tag " + (selectedExpense.receipt ? "good" : "warning")}>{selectedExpense.receipt ? "Présent dans la démo" : "Manquant"}</span></div>{!selectedExpense.receipt && <label className="file-drop">Ajouter un justificatif<input type="file" accept="image/*,.pdf" onChange={(event) => {if(event.target.files?.length) {setExpenses(expenses.map((expense) => expense.id === selectedExpense.id ? {...expense, receipt:true} : expense)); setSelectedExpense({...selectedExpense, receipt:true}); setToast("Justificatif ajouté à la démonstration.");}}}/></label>}<button className="delete-expense" onClick={() => {setExpenses(expenses.filter((expense) => expense.id !== selectedExpense.id));closeModal();setToast("Dépense retirée de la démonstration.");}}>Supprimer cette dépense</button></>}
    </dialog>
    {toast && <div className="demo-toast" role="status"><span>✓</span>{toast}<button aria-label="Fermer le message" onClick={() => setToast("")}><Icon name="close" size={16}/></button></div>}
  </div>;
}
