/// <reference types="expo/types" />

// Ce fichier est maintenu par Expo.
