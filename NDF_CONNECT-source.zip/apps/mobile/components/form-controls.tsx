import type { ReactNode } from "react";
import {
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  type TextInputProps,
  View,
} from "react-native";

import { colors } from "@/lib/theme";

export function Field({ label, ...props }: TextInputProps & { label: string }) {
  return (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        placeholderTextColor="#929D96"
        style={[styles.input, props.editable === false && styles.disabled]}
        {...props}
      />
    </View>
  );
}

export function ChoiceField<T extends string>({
  getLabel,
  label,
  onChange,
  options,
  value,
}: {
  getLabel: (value: T) => string;
  label: string;
  onChange: (value: T) => void;
  options: readonly T[];
  value: string;
}) {
  return (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <View style={styles.choices}>
        {options.map((option) => (
          <Pressable
            key={option}
            onPress={() => onChange(option)}
            style={[styles.choice, value === option && styles.choiceActive]}
          >
            <Text style={[styles.choiceText, value === option && styles.choiceTextActive]}>
              {getLabel(option)}
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

export function PrimaryButton({
  children,
  disabled,
  onPress,
}: {
  children: ReactNode;
  disabled?: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        pressed && styles.buttonPressed,
        disabled && styles.buttonDisabled,
      ]}
    >
      <Text style={styles.buttonText}>{children}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    alignItems: "center",
    backgroundColor: colors.brand,
    borderRadius: 12,
    minHeight: 50,
    justifyContent: "center",
    paddingHorizontal: 18,
  },
  buttonDisabled: { opacity: 0.55 },
  buttonPressed: { backgroundColor: colors.brandDark },
  buttonText: { color: "white", fontSize: 16, fontWeight: "700" },
  choice: {
    backgroundColor: colors.background,
    borderColor: colors.border,
    borderRadius: 99,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 9,
  },
  choiceActive: { backgroundColor: colors.mint, borderColor: colors.brand },
  choiceText: { color: colors.muted, fontSize: 12, fontWeight: "600" },
  choiceTextActive: { color: colors.brandDark },
  choices: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  disabled: { backgroundColor: "#EFF2F0", color: colors.muted },
  field: { gap: 7 },
  input: {
    backgroundColor: colors.surface,
    borderColor: "#CCD6CF",
    borderRadius: 12,
    borderWidth: 1,
    color: colors.ink,
    fontSize: 16,
    minHeight: 50,
    paddingHorizontal: 14,
  },
  label: { color: "#3C473F", fontSize: 13, fontWeight: "700" },
});
