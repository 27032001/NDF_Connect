import { Link } from "expo-router";
import { SafeAreaView, ScrollView, StyleSheet, Text, View } from "react-native";

import { PrimaryButton } from "@/components/form-controls";
import { supabase } from "@/lib/supabase";
import { colors } from "@/lib/theme";
import { useAuth } from "@/providers/auth-provider";

export default function HomeScreen() {
  const { session } = useAuth();

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.header}>
          <View style={styles.brandMark}><Text style={styles.brandLetter}>N</Text></View>
          <Text style={styles.brandName}>NDF CONNECT</Text>
        </View>
        <View style={styles.intro}>
          <Text style={styles.eyebrow}>VOTRE ESPACE</Text>
          <Text style={styles.title}>Bonjour,</Text>
          <Text style={styles.subtitle}>{session?.user.email}</Text>
        </View>

        <View style={styles.cardAccent}>
          <Text style={styles.cardEyebrow}>PREMIÈRE ÉTAPE</Text>
          <Text style={styles.cardTitle}>Complétez votre profil</Text>
          <Text style={styles.cardBody}>Ces informations serviront à personnaliser votre future checklist administrative.</Text>
          <Link href="/(app)/profile" style={styles.link}>Ouvrir mon profil →</Link>
        </View>

        <View style={styles.placeholderGrid}>
          <View style={styles.placeholder}><Text style={styles.placeholderValue}>—</Text><Text style={styles.placeholderLabel}>Dépenses · Sprint 2</Text></View>
          <View style={styles.placeholder}><Text style={styles.placeholderValue}>—</Text><Text style={styles.placeholderLabel}>Checklist · Sprint 4</Text></View>
        </View>

        <PrimaryButton onPress={() => void supabase.auth.signOut()}>Se déconnecter</PrimaryButton>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  brandLetter: { color: "#263529", fontSize: 17, fontWeight: "900" },
  brandMark: { alignItems: "center", backgroundColor: colors.warm, borderRadius: 10, height: 36, justifyContent: "center", width: 36 },
  brandName: { color: colors.ink, fontSize: 13, fontWeight: "900", letterSpacing: .7 },
  cardAccent: { backgroundColor: colors.brandDark, borderRadius: 20, gap: 9, padding: 22 },
  cardBody: { color: "#C9DED1", fontSize: 15, lineHeight: 22 },
  cardEyebrow: { color: "#A9D9BD", fontSize: 11, fontWeight: "800", letterSpacing: 1.5 },
  cardTitle: { color: "white", fontSize: 24, fontWeight: "800" },
  container: { gap: 24, padding: 22 },
  eyebrow: { color: colors.brand, fontSize: 11, fontWeight: "800", letterSpacing: 1.7 },
  header: { alignItems: "center", flexDirection: "row", gap: 10 },
  intro: { gap: 5, marginTop: 16 },
  link: { color: colors.warm, fontSize: 15, fontWeight: "800", marginTop: 6 },
  placeholder: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 16, borderWidth: 1, flex: 1, gap: 7, padding: 17 },
  placeholderGrid: { flexDirection: "row", gap: 12 },
  placeholderLabel: { color: colors.muted, fontSize: 12, lineHeight: 17 },
  placeholderValue: { color: colors.ink, fontSize: 28, fontWeight: "800" },
  safe: { backgroundColor: colors.background, flex: 1 },
  subtitle: { color: colors.muted, fontSize: 15 },
  title: { color: colors.ink, fontSize: 38, fontWeight: "800", letterSpacing: -1.4 },
});
