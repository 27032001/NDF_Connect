import { Redirect, Stack } from "expo-router";
import { ActivityIndicator, StyleSheet, View } from "react-native";

import { colors } from "@/lib/theme";
import { useAuth } from "@/providers/auth-provider";

export default function AppLayout() {
  const { loading, session } = useAuth();

  if (loading) {
    return <View style={styles.loading}><ActivityIndicator color={colors.brand} /></View>;
  }
  if (!session) return <Redirect href="/login" />;

  return (
    <Stack
      screenOptions={{
        contentStyle: { backgroundColor: colors.background },
        headerShadowVisible: false,
        headerStyle: { backgroundColor: colors.background },
        headerTintColor: colors.ink,
      }}
    >
      <Stack.Screen name="home" options={{ headerShown: false }} />
      <Stack.Screen name="profile" options={{ title: "Mon profil" }} />
    </Stack>
  );
}

const styles = StyleSheet.create({
  loading: { alignItems: "center", backgroundColor: colors.background, flex: 1, justifyContent: "center" },
});
