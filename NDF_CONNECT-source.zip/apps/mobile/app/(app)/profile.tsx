import {
  administrativeStatuses,
  apprenticeshipStatuses,
  profileLabels,
  profileSchema,
  studentStatuses,
  type ProfileRow,
} from "@ndf-connect/shared";
import { useEffect, useState } from "react";
import { ActivityIndicator, SafeAreaView, ScrollView, StyleSheet, Text, View } from "react-native";

import { ChoiceField, Field, PrimaryButton } from "@/components/form-controls";
import { supabase } from "@/lib/supabase";
import { colors } from "@/lib/theme";
import { useAuth } from "@/providers/auth-provider";

type FormState = {
  administrative_status: string;
  apprenticeship_status: string;
  first_name: string;
  last_name: string;
  nationality_code: string;
  origin_country_code: string;
  residence_country_code: string;
  residence_document_expiry: string;
  residence_document_type: string;
  student_status: string;
};

const emptyForm: FormState = {
  administrative_status: "",
  apprenticeship_status: "",
  first_name: "",
  last_name: "",
  nationality_code: "",
  origin_country_code: "",
  residence_country_code: "FR",
  residence_document_expiry: "",
  residence_document_type: "",
  student_status: "",
};

function fromProfile(profile: ProfileRow): FormState {
  return {
    administrative_status: profile.administrative_status ?? "",
    apprenticeship_status: profile.apprenticeship_status ?? "",
    first_name: profile.first_name,
    last_name: profile.last_name,
    nationality_code: profile.nationality_code ?? "",
    origin_country_code: profile.origin_country_code ?? "",
    residence_country_code: profile.residence_country_code ?? "FR",
    residence_document_expiry: profile.residence_document_expiry ?? "",
    residence_document_type: profile.residence_document_type ?? "",
    student_status: profile.student_status ?? "",
  };
}

export default function ProfileScreen() {
  const { session } = useAuth();
  const [form, setForm] = useState<FormState>(emptyForm);
  const [fetching, setFetching] = useState(true);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<{ error: boolean; text: string } | null>(null);

  useEffect(() => {
    if (!session) return;
    let mounted = true;

    void supabase
      .from("profiles")
      .select("*")
      .eq("id", session.user.id)
      .maybeSingle()
      .then(({ data, error }) => {
        if (!mounted) return;
        if (data) setForm(fromProfile(data));
        if (error) setFeedback({ error: true, text: error.message });
        setFetching(false);
      });

    return () => { mounted = false; };
  }, [session]);

  function update(field: keyof FormState, value: string) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  async function save() {
    if (!session) return;
    setFeedback(null);
    const parsed = profileSchema.safeParse(form);
    if (!parsed.success) {
      setFeedback({ error: true, text: parsed.error.issues[0]?.message ?? "Vérifiez les informations." });
      return;
    }

    setSaving(true);
    const { error } = await supabase.from("profiles").upsert(
      { id: session.user.id, ...parsed.data },
      { onConflict: "id" },
    );
    setSaving(false);
    setFeedback(error
      ? { error: true, text: error.message }
      : { error: false, text: "Votre profil a bien été enregistré." });
  }

  if (fetching) {
    return <View style={styles.loading}><ActivityIndicator color={colors.brand} size="large" /></View>;
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <View style={styles.intro}>
          <Text style={styles.eyebrow}>MON COMPTE</Text>
          <Text style={styles.title}>Votre profil</Text>
          <Text style={styles.subtitle}>Ces informations personnaliseront votre parcours administratif.</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Identité</Text>
          <Field label="Prénom" onChangeText={(value) => update("first_name", value)} value={form.first_name} />
          <Field label="Nom" onChangeText={(value) => update("last_name", value)} value={form.last_name} />
          <Field editable={false} label="Adresse e-mail" value={session?.user.email ?? ""} />
          <Field autoCapitalize="characters" label="Nationalité · code pays" maxLength={2} onChangeText={(value) => update("nationality_code", value.toUpperCase())} placeholder="GA" value={form.nationality_code} />
          <Field autoCapitalize="characters" label="Pays de provenance · code pays" maxLength={2} onChangeText={(value) => update("origin_country_code", value.toUpperCase())} placeholder="GA" value={form.origin_country_code} />
          <Field autoCapitalize="characters" label="Pays de résidence · code pays" maxLength={2} onChangeText={(value) => update("residence_country_code", value.toUpperCase())} placeholder="FR" value={form.residence_country_code} />
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Situation</Text>
          <ChoiceField getLabel={(value) => profileLabels.studentStatus[value]} label="Statut étudiant" onChange={(value) => update("student_status", value)} options={studentStatuses} value={form.student_status} />
          <ChoiceField getLabel={(value) => profileLabels.apprenticeshipStatus[value]} label="Alternance" onChange={(value) => update("apprenticeship_status", value)} options={apprenticeshipStatuses} value={form.apprenticeship_status} />
          <ChoiceField getLabel={(value) => profileLabels.administrativeStatus[value]} label="Situation administrative" onChange={(value) => update("administrative_status", value)} options={administrativeStatuses} value={form.administrative_status} />
          <Field label="Type de document de séjour" onChangeText={(value) => update("residence_document_type", value)} placeholder="Titre de séjour étudiant" value={form.residence_document_type} />
          <Field autoCapitalize="none" label="Date d’expiration · AAAA-MM-JJ" onChangeText={(value) => update("residence_document_expiry", value)} placeholder="2027-09-15" value={form.residence_document_expiry} />
        </View>

        {feedback ? <Text style={feedback.error ? styles.error : styles.success}>{feedback.text}</Text> : null}
        <PrimaryButton disabled={saving} onPress={() => void save()}>{saving ? "Enregistrement…" : "Enregistrer le profil"}</PrimaryButton>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 18, borderWidth: 1, gap: 17, padding: 18 },
  container: { gap: 18, padding: 20, paddingBottom: 40 },
  error: { backgroundColor: "#FFF0EF", borderRadius: 10, color: colors.danger, lineHeight: 20, padding: 12 },
  eyebrow: { color: colors.brand, fontSize: 11, fontWeight: "800", letterSpacing: 1.7 },
  intro: { gap: 7, marginBottom: 4 },
  loading: { alignItems: "center", backgroundColor: colors.background, flex: 1, justifyContent: "center" },
  safe: { backgroundColor: colors.background, flex: 1 },
  sectionTitle: { color: colors.ink, fontSize: 20, fontWeight: "800", marginBottom: 2 },
  subtitle: { color: colors.muted, fontSize: 15, lineHeight: 22 },
  success: { backgroundColor: "#E8F6ED", borderRadius: 10, color: colors.brand, lineHeight: 20, padding: 12 },
  title: { color: colors.ink, fontSize: 34, fontWeight: "800", letterSpacing: -1.2 },
});
