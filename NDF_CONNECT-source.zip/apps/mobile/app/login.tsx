import { authCredentialsSchema } from "@ndf-connect/shared";
import { Redirect, useRouter } from "expo-router";
import { useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { Field, PrimaryButton } from "@/components/form-controls";
import { supabase } from "@/lib/supabase";
import { colors } from "@/lib/theme";
import { useAuth } from "@/providers/auth-provider";

export default function LoginScreen() {
  const router = useRouter();
  const { session } = useAuth();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ error: boolean; text: string } | null>(null);

  if (session) return <Redirect href="/(app)/home" />;

  async function submit() {
    setFeedback(null);
    const parsed = authCredentialsSchema.safeParse({ email, password });
    if (!parsed.success) {
      setFeedback({ error: true, text: parsed.error.issues[0]?.message ?? "Vérifiez les champs." });
      return;
    }

    setLoading(true);
    const result = mode === "login"
      ? await supabase.auth.signInWithPassword(parsed.data)
      : await supabase.auth.signUp(parsed.data);
    setLoading(false);

    if (result.error) {
      setFeedback({ error: true, text: result.error.message });
    } else if (mode === "signup" && !result.data.session) {
      setFeedback({ error: false, text: "Compte créé. Confirmez votre adresse e-mail." });
    } else {
      router.replace("/(app)/home");
    }
  }

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.safe}>
        <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
          <View style={styles.brandMark}><Text style={styles.brandLetter}>N</Text></View>
          <Text style={styles.eyebrow}>NDF CONNECT</Text>
          <Text style={styles.title}>Votre quotidien administratif, simplifié.</Text>
          <Text style={styles.subtitle}>Connectez-vous pour retrouver votre espace personnel.</Text>

          <View style={styles.card}>
            <View style={styles.segmented}>
              {(["login", "signup"] as const).map((item) => (
                <Pressable key={item} onPress={() => setMode(item)} style={[styles.segment, mode === item && styles.segmentActive]}>
                  <Text style={[styles.segmentText, mode === item && styles.segmentTextActive]}>
                    {item === "login" ? "Connexion" : "Inscription"}
                  </Text>
                </Pressable>
              ))}
            </View>
            <Field autoCapitalize="none" autoComplete="email" keyboardType="email-address" label="Adresse e-mail" onChangeText={setEmail} placeholder="vous@exemple.fr" value={email} />
            <Field autoCapitalize="none" autoComplete={mode === "login" ? "current-password" : "new-password"} label="Mot de passe" onChangeText={setPassword} placeholder="8 caractères minimum" secureTextEntry value={password} />
            {feedback ? <Text style={feedback.error ? styles.error : styles.success}>{feedback.text}</Text> : null}
            <PrimaryButton disabled={loading} onPress={() => void submit()}>
              {loading ? "Chargement…" : mode === "login" ? "Se connecter" : "Créer mon compte"}
            </PrimaryButton>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  brandLetter: { color: "#263529", fontSize: 24, fontWeight: "900" },
  brandMark: { alignItems: "center", backgroundColor: colors.warm, borderRadius: 16, height: 52, justifyContent: "center", width: 52 },
  card: { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: 20, borderWidth: 1, gap: 18, padding: 20 },
  container: { gap: 14, justifyContent: "center", minHeight: "100%", padding: 22 },
  error: { backgroundColor: "#FFF0EF", borderRadius: 10, color: colors.danger, lineHeight: 20, padding: 12 },
  eyebrow: { color: colors.brand, fontSize: 12, fontWeight: "800", letterSpacing: 1.8, marginTop: 8 },
  safe: { backgroundColor: colors.background, flex: 1 },
  segment: { alignItems: "center", borderRadius: 9, flex: 1, paddingVertical: 10 },
  segmentActive: { backgroundColor: colors.surface },
  segmented: { backgroundColor: colors.background, borderRadius: 12, flexDirection: "row", padding: 4 },
  segmentText: { color: colors.muted, fontWeight: "600" },
  segmentTextActive: { color: colors.ink, fontWeight: "800" },
  subtitle: { color: colors.muted, fontSize: 16, lineHeight: 24, marginBottom: 12 },
  success: { backgroundColor: "#E8F6ED", borderRadius: 10, color: colors.brand, lineHeight: 20, padding: 12 },
  title: { color: colors.ink, fontSize: 34, fontWeight: "800", letterSpacing: -1.2, lineHeight: 38 },
});
