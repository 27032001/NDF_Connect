export const colors = {
  background: "#F4F7F4",
  border: "#DDE5DF",
  brand: "#195C3F",
  brandDark: "#10462F",
  danger: "#A33A36",
  ink: "#17211B",
  mint: "#DFF3E7",
  muted: "#68736C",
  surface: "#FFFFFF",
  warm: "#EDB34C",
} as const;
