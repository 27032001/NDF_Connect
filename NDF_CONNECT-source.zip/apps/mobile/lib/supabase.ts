import type { Database } from "@ndf-connect/shared";
import { createClient, processLock } from "@supabase/supabase-js";
import * as SecureStore from "expo-secure-store";
import { AppState } from "react-native";

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!url || !anonKey) {
  throw new Error(
    "Configuration Supabase absente. Copiez .env.example vers .env dans apps/mobile.",
  );
}

const chunkSize = 1800;
const metaKey = (key: string) => `${key}__meta`;
const chunkKey = (key: string, index: number) => `${key}__${index}`;

const secureStorage = {
  async getItem(key: string) {
    const rawCount = await SecureStore.getItemAsync(metaKey(key));
    if (!rawCount) return SecureStore.getItemAsync(key);

    const count = Number(rawCount);
    if (!Number.isSafeInteger(count) || count < 1) return null;

    const chunks = await Promise.all(
      Array.from({ length: count }, (_, index) =>
        SecureStore.getItemAsync(chunkKey(key, index)),
      ),
    );

    return chunks.every((chunk): chunk is string => chunk !== null)
      ? chunks.join("")
      : null;
  },
  async removeItem(key: string) {
    const rawCount = await SecureStore.getItemAsync(metaKey(key));
    const count = Number(rawCount ?? 0);

    await Promise.all([
      SecureStore.deleteItemAsync(key),
      SecureStore.deleteItemAsync(metaKey(key)),
      ...Array.from({ length: Number.isSafeInteger(count) ? count : 0 }, (_, index) =>
        SecureStore.deleteItemAsync(chunkKey(key, index)),
      ),
    ]);
  },
  async setItem(key: string, value: string) {
    await this.removeItem(key);
    const chunks = value.match(new RegExp(`.{1,${chunkSize}}`, "gs")) ?? [""];

    await Promise.all(
      chunks.map((chunk, index) =>
        SecureStore.setItemAsync(chunkKey(key, index), chunk, {
          keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK,
        }),
      ),
    );
    await SecureStore.setItemAsync(metaKey(key), String(chunks.length), {
      keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK,
    });
  },
};

export const supabase = createClient<Database>(url, anonKey, {
  auth: {
    autoRefreshToken: true,
    detectSessionInUrl: false,
    lock: processLock,
    persistSession: true,
    storage: secureStorage,
  },
});

AppState.addEventListener("change", (state) => {
  if (state === "active") supabase.auth.startAutoRefresh();
  else supabase.auth.stopAutoRefresh();
});
