"use client";

import {
  administrativeStatuses,
  apprenticeshipStatuses,
  profileLabels,
  profileSchema,
  studentStatuses,
  type ProfileRow,
} from "@ndf-connect/shared";
import { type FormEvent, useState } from "react";

import { createClient } from "@/lib/supabase/client";

type FormState = {
  administrative_status: string;
  apprenticeship_status: string;
  first_name: string;
  last_name: string;
  nationality_code: string;
  origin_country_code: string;
  residence_country_code: string;
  residence_document_expiry: string;
  residence_document_type: string;
  student_status: string;
};

function getInitialState(profile: ProfileRow | null): FormState {
  return {
    administrative_status: profile?.administrative_status ?? "",
    apprenticeship_status: profile?.apprenticeship_status ?? "",
    first_name: profile?.first_name ?? "",
    last_name: profile?.last_name ?? "",
    nationality_code: profile?.nationality_code ?? "",
    origin_country_code: profile?.origin_country_code ?? "",
    residence_country_code: profile?.residence_country_code ?? "FR",
    residence_document_expiry: profile?.residence_document_expiry ?? "",
    residence_document_type: profile?.residence_document_type ?? "",
    student_status: profile?.student_status ?? "",
  };
}

export function ProfileForm({
  email,
  initialProfile,
  userId,
}: {
  email: string;
  initialProfile: ProfileRow | null;
  userId: string;
}) {
  const [form, setForm] = useState(() => getInitialState(initialProfile));
  const [feedback, setFeedback] = useState<{ kind: "error" | "success"; text: string } | null>(null);
  const [loading, setLoading] = useState(false);

  function update(field: keyof FormState, value: string) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFeedback(null);

    const parsed = profileSchema.safeParse(form);
    if (!parsed.success) {
      setFeedback({
        kind: "error",
        text: parsed.error.issues[0]?.message ?? "Vérifiez les informations saisies.",
      });
      return;
    }

    setLoading(true);
    const { error } = await createClient()
      .from("profiles")
      .upsert({ id: userId, ...parsed.data }, { onConflict: "id" });
    setLoading(false);

    setFeedback(
      error
        ? { kind: "error", text: error.message }
        : { kind: "success", text: "Votre profil a bien été enregistré." },
    );
  }

  return (
    <form className="profile-card" onSubmit={handleSubmit}>
      <fieldset>
        <legend>Identité</legend>
        <div className="form-grid">
          <label>
            Prénom
            <input value={form.first_name} onChange={(e) => update("first_name", e.target.value)} required />
          </label>
          <label>
            Nom
            <input value={form.last_name} onChange={(e) => update("last_name", e.target.value)} required />
          </label>
          <label className="full-width">
            Adresse e-mail
            <input value={email} disabled type="email" />
            <small>L’adresse e-mail est gérée par votre compte sécurisé.</small>
          </label>
          <label>
            Nationalité
            <input maxLength={2} placeholder="GA" value={form.nationality_code} onChange={(e) => update("nationality_code", e.target.value.toUpperCase())} />
          </label>
          <label>
            Pays de provenance
            <input maxLength={2} placeholder="GA" value={form.origin_country_code} onChange={(e) => update("origin_country_code", e.target.value.toUpperCase())} />
          </label>
          <label>
            Pays de résidence
            <input maxLength={2} placeholder="FR" value={form.residence_country_code} onChange={(e) => update("residence_country_code", e.target.value.toUpperCase())} />
          </label>
        </div>
      </fieldset>

      <fieldset>
        <legend>Situation</legend>
        <div className="form-grid">
          <label>
            Statut étudiant
            <select value={form.student_status} onChange={(e) => update("student_status", e.target.value)}>
              <option value="">Sélectionner</option>
              {studentStatuses.map((value) => <option value={value} key={value}>{profileLabels.studentStatus[value]}</option>)}
            </select>
          </label>
          <label>
            Alternance
            <select value={form.apprenticeship_status} onChange={(e) => update("apprenticeship_status", e.target.value)}>
              <option value="">Sélectionner</option>
              {apprenticeshipStatuses.map((value) => <option value={value} key={value}>{profileLabels.apprenticeshipStatus[value]}</option>)}
            </select>
          </label>
          <label className="full-width">
            Situation administrative
            <select value={form.administrative_status} onChange={(e) => update("administrative_status", e.target.value)}>
              <option value="">Sélectionner</option>
              {administrativeStatuses.map((value) => <option value={value} key={value}>{profileLabels.administrativeStatus[value]}</option>)}
            </select>
          </label>
          <label>
            Type de document de séjour
            <input placeholder="Titre de séjour étudiant" value={form.residence_document_type} onChange={(e) => update("residence_document_type", e.target.value)} />
          </label>
          <label>
            Date d’expiration
            <input type="date" value={form.residence_document_expiry} onChange={(e) => update("residence_document_expiry", e.target.value)} />
          </label>
        </div>
      </fieldset>

      {feedback ? <p className={`feedback ${feedback.kind}`} role="status">{feedback.text}</p> : null}
      <div className="form-actions">
        <button className="primary-button" disabled={loading} type="submit">
          {loading ? "Enregistrement…" : "Enregistrer le profil"}
        </button>
      </div>
    </form>
  );
}
