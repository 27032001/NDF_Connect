"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

import { createClient } from "@/lib/supabase/client";

export function SignOutButton() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  return (
    <button
      className="ghost-button"
      disabled={loading}
      onClick={async () => {
        setLoading(true);
        await createClient().auth.signOut();
        router.replace("/login");
        router.refresh();
      }}
      type="button"
    >
      {loading ? "Déconnexion…" : "Se déconnecter"}
    </button>
  );
}
