"use client";

import { authCredentialsSchema } from "@ndf-connect/shared";
import { useRouter } from "next/navigation";
import { type FormEvent, useState } from "react";

import { createClient } from "@/lib/supabase/client";

type Mode = "login" | "signup";

export function AuthForm() {
  const router = useRouter();
  const [mode, setMode] = useState<Mode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);

    const parsed = authCredentialsSchema.safeParse({ email, password });
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? "Vérifiez les champs saisis.");
      return;
    }

    setLoading(true);
    const supabase = createClient();

    const result =
      mode === "login"
        ? await supabase.auth.signInWithPassword(parsed.data)
        : await supabase.auth.signUp(parsed.data);

    setLoading(false);

    if (result.error) {
      setError(result.error.message);
      return;
    }

    if (mode === "signup" && !result.data.session) {
      setMessage("Compte créé. Consultez votre e-mail pour confirmer l’inscription.");
      return;
    }

    router.replace("/dashboard");
    router.refresh();
  }

  return (
    <div className="auth-card">
      <p className="eyebrow">ESPACE PERSONNEL</p>
      <h2>{mode === "login" ? "Bon retour" : "Créer votre compte"}</h2>
      <p className="muted">
        {mode === "login"
          ? "Connectez-vous pour retrouver votre dossier."
          : "Commencez avec votre adresse e-mail."}
      </p>

      <div className="segmented" aria-label="Choisir le mode d’authentification">
        <button
          className={mode === "login" ? "active" : ""}
          type="button"
          onClick={() => setMode("login")}
        >
          Connexion
        </button>
        <button
          className={mode === "signup" ? "active" : ""}
          type="button"
          onClick={() => setMode("signup")}
        >
          Inscription
        </button>
      </div>

      <form onSubmit={handleSubmit} className="form-stack">
        <label>
          Adresse e-mail
          <input
            autoComplete="email"
            inputMode="email"
            onChange={(event) => setEmail(event.target.value)}
            placeholder="vous@exemple.fr"
            required
            type="email"
            value={email}
          />
        </label>
        <label>
          Mot de passe
          <input
            autoComplete={mode === "login" ? "current-password" : "new-password"}
            minLength={8}
            onChange={(event) => setPassword(event.target.value)}
            placeholder="8 caractères minimum"
            required
            type="password"
            value={password}
          />
        </label>

        {error ? <p className="feedback error" role="alert">{error}</p> : null}
        {message ? <p className="feedback success" role="status">{message}</p> : null}

        <button className="primary-button" disabled={loading} type="submit">
          {loading
            ? "Chargement…"
            : mode === "login"
              ? "Se connecter"
              : "Créer mon compte"}
        </button>
      </form>
    </div>
  );
}
