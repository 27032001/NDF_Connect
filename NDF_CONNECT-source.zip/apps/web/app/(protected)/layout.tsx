import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";

import { SignOutButton } from "@/components/sign-out-button";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

export default async function ProtectedLayout({ children }: { children: ReactNode }) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  return (
    <div className="app-shell">
      <header className="topbar">
        <Link className="brand-link" href="/dashboard">
          <span className="brand-mark small">N</span>
          <span>NDF CONNECT</span>
        </Link>
        <nav aria-label="Navigation principale">
          <Link href="/dashboard">Tableau de bord</Link>
          <Link href="/profile">Profil</Link>
        </nav>
        <SignOutButton />
      </header>
      <main className="content">{children}</main>
    </div>
  );
}
