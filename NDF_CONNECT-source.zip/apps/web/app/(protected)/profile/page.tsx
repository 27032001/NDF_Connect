import { ProfileForm } from "@/components/profile-form";
import { createClient } from "@/lib/supabase/server";

export default async function ProfilePage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user!.id)
    .maybeSingle();

  return (
    <div className="page-stack narrow">
      <section className="page-heading">
        <div>
          <p className="eyebrow">MON COMPTE</p>
          <h1>Votre profil</h1>
          <p className="muted">
            Ces informations serviront à personnaliser votre parcours administratif.
          </p>
        </div>
      </section>
      <ProfileForm email={user!.email ?? ""} initialProfile={profile} userId={user!.id} />
    </div>
  );
}
