import Link from "next/link";

import { createClient } from "@/lib/supabase/server";

const profileFields = [
  "first_name",
  "last_name",
  "nationality_code",
  "origin_country_code",
  "residence_country_code",
  "student_status",
  "apprenticeship_status",
  "administrative_status",
] as const;

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user!.id)
    .maybeSingle();

  const completed = profile
    ? profileFields.filter((field) => Boolean(profile[field])).length
    : 0;
  const completion = Math.round((completed / profileFields.length) * 100);
  const displayName = profile?.first_name || user?.email?.split("@")[0] || "Bienvenue";

  return (
    <div className="page-stack">
      <section className="page-heading">
        <div>
          <p className="eyebrow">TABLEAU DE BORD</p>
          <h1>Bonjour {displayName},</h1>
          <p className="muted">Voici l’état de votre espace NDF CONNECT.</p>
        </div>
        <Link className="primary-link" href="/profile">Compléter mon profil</Link>
      </section>

      <section className="metrics" aria-label="Indicateurs">
        <article className="metric-card accent">
          <p>Profil complété</p>
          <strong>{completion} %</strong>
          <div className="progress-track" aria-label={`Profil complété à ${completion} %`}>
            <span style={{ width: `${completion}%` }} />
          </div>
        </article>
        <article className="metric-card">
          <p>Dépenses ce mois</p>
          <strong>—</strong>
          <span className="tag">Sprint 2</span>
        </article>
        <article className="metric-card">
          <p>Dossier administratif</p>
          <strong>—</strong>
          <span className="tag">Sprint 4</span>
        </article>
      </section>

      <section className="panel">
        <div>
          <p className="eyebrow">PREMIÈRE ÉTAPE</p>
          <h2>Personnalisez votre espace</h2>
          <p className="muted">
            Votre pays, votre statut étudiant et votre situation administrative
            permettront de construire votre checklist lors du Sprint 4.
          </p>
        </div>
        <Link className="secondary-link" href="/profile">Ouvrir mon profil →</Link>
      </section>
    </div>
  );
}
