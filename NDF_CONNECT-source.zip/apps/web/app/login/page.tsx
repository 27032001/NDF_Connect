import { redirect } from "next/navigation";

import { AuthForm } from "@/components/auth-form";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (user) redirect("/dashboard");

  return (
    <main className="auth-shell">
      <section className="brand-panel">
        <div className="brand-mark">N</div>
        <p className="eyebrow">NDF CONNECT</p>
        <h1>Vos démarches et vos dépenses, au même endroit.</h1>
        <p className="lead">
          Un espace pensé pour les étudiants et alternants, notamment lorsqu’ils
          arrivent de l’étranger.
        </p>
        <div className="trust-note">
          <span aria-hidden="true">✓</span>
          Vos données restent privées et isolées par compte.
        </div>
      </section>
      <section className="auth-card-wrap">
        <AuthForm />
      </section>
    </main>
  );
}
