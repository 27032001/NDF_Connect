import type { Database } from "@ndf-connect/shared";
import { createBrowserClient } from "@supabase/ssr";

import { getSupabaseEnv } from "./env";

export function createClient() {
  const { anonKey, url } = getSupabaseEnv();

  return createBrowserClient<Database>(url, anonKey);
}
