export const studentStatuses = ["student", "former_student", "not_student"] as const;

export const apprenticeshipStatuses = [
  "apprentice",
  "searching",
  "not_applicable",
] as const;

export const administrativeStatuses = [
  "eu_citizen",
  "student_residence_permit",
  "other_residence_permit",
  "visa",
  "other",
] as const;

export const profileLabels = {
  studentStatus: {
    student: "Étudiant",
    former_student: "Ancien étudiant",
    not_student: "Non étudiant",
  },
  apprenticeshipStatus: {
    apprentice: "En alternance",
    searching: "Recherche d’alternance",
    not_applicable: "Non concerné",
  },
  administrativeStatus: {
    eu_citizen: "Citoyen UE/EEE/Suisse",
    student_residence_permit: "Titre de séjour étudiant",
    other_residence_permit: "Autre titre de séjour",
    visa: "Visa",
    other: "Autre situation",
  },
} as const;
