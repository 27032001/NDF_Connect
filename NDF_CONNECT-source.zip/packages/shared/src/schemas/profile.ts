import { z } from "zod";

import {
  administrativeStatuses,
  apprenticeshipStatuses,
  studentStatuses,
} from "../constants/profile";

const emptyStringToNull = (value: unknown) => (value === "" ? null : value);

const countryCodeSchema = z.preprocess(
  emptyStringToNull,
  z
    .string()
    .trim()
    .toUpperCase()
    .regex(/^[A-Z]{2}$/, "Utilisez un code pays ISO à deux lettres.")
    .nullable(),
);

const optionalTextSchema = z.preprocess(
  emptyStringToNull,
  z.string().trim().max(120).nullable(),
);

const optionalDateSchema = z.preprocess(
  emptyStringToNull,
  z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "Utilisez le format AAAA-MM-JJ.")
    .nullable(),
);

export const profileSchema = z.object({
  first_name: z.string().trim().min(1, "Le prénom est requis.").max(80),
  last_name: z.string().trim().min(1, "Le nom est requis.").max(80),
  nationality_code: countryCodeSchema,
  origin_country_code: countryCodeSchema,
  residence_country_code: countryCodeSchema,
  student_status: z.enum(studentStatuses).nullable(),
  apprenticeship_status: z.enum(apprenticeshipStatuses).nullable(),
  administrative_status: z.enum(administrativeStatuses).nullable(),
  residence_document_type: optionalTextSchema,
  residence_document_expiry: optionalDateSchema,
});

export type ProfileInput = z.infer<typeof profileSchema>;
