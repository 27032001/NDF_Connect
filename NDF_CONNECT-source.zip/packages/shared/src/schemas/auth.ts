import { z } from "zod";

export const authCredentialsSchema = z.object({
  email: z.email("Adresse e-mail invalide."),
  password: z
    .string()
    .min(8, "Le mot de passe doit contenir au moins 8 caractères."),
});

export type AuthCredentials = z.infer<typeof authCredentialsSchema>;
