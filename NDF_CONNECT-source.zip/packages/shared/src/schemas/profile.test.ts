import { describe, expect, it } from "vitest";

import { profileSchema } from "./profile";

const validProfile = {
  first_name: "Ada",
  last_name: "Lovelace",
  nationality_code: "gb",
  origin_country_code: "GB",
  residence_country_code: "FR",
  student_status: "student",
  apprenticeship_status: "apprentice",
  administrative_status: "student_residence_permit",
  residence_document_type: "Titre de séjour étudiant",
  residence_document_expiry: "2027-09-15",
};

describe("profileSchema", () => {
  it("normalise les codes pays et accepte un profil complet", () => {
    const result = profileSchema.parse(validProfile);

    expect(result.nationality_code).toBe("GB");
  });

  it("convertit les champs facultatifs vides en null", () => {
    const result = profileSchema.parse({
      ...validProfile,
      residence_document_type: "",
      residence_document_expiry: "",
    });

    expect(result.residence_document_type).toBeNull();
    expect(result.residence_document_expiry).toBeNull();
  });

  it("refuse un code pays non ISO alpha-2", () => {
    const result = profileSchema.safeParse({
      ...validProfile,
      origin_country_code: "GAB",
    });

    expect(result.success).toBe(false);
  });
});
