begin;

select plan(6);

insert into auth.users (id, email, encrypted_password, created_at, updated_at)
values
  ('11111111-1111-4111-8111-111111111111', 'alice@example.test', '', now(), now()),
  ('22222222-2222-4222-8222-222222222222', 'bob@example.test', '', now(), now());

reset role;
set local role authenticated;
select set_config('request.jwt.claim.sub', '11111111-1111-4111-8111-111111111111', true);

select is(
  (select count(*) from public.profiles),
  1::bigint,
  'Alice ne voit que son propre profil'
);

select results_eq(
  $$ select id from public.profiles $$,
  $$ values ('11111111-1111-4111-8111-111111111111'::uuid) $$,
  'Le profil visible appartient bien à Alice'
);

select lives_ok(
  $$ update public.profiles set first_name = 'Alice' where id = '11111111-1111-4111-8111-111111111111' $$,
  'Alice peut modifier son profil'
);

select is(
  (select first_name from public.profiles where id = '11111111-1111-4111-8111-111111111111'),
  'Alice',
  'La modification autorisée est enregistrée'
);

select lives_ok(
  $$ update public.profiles set first_name = 'Intrusion' where id = '22222222-2222-4222-8222-222222222222' $$,
  'Une tentative sur le profil Bob ne divulgue pas son existence'
);

reset role;
select is(
  (select first_name from public.profiles where id = '22222222-2222-4222-8222-222222222222'),
  '',
  'Le profil Bob reste inchangé'
);

select * from finish();
rollback;
