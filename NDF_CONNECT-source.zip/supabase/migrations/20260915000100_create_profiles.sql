create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  first_name text not null default '' check (char_length(first_name) <= 80),
  last_name text not null default '' check (char_length(last_name) <= 80),
  nationality_code text check (nationality_code is null or nationality_code ~ '^[A-Z]{2}$'),
  origin_country_code text check (origin_country_code is null or origin_country_code ~ '^[A-Z]{2}$'),
  residence_country_code text check (residence_country_code is null or residence_country_code ~ '^[A-Z]{2}$'),
  student_status text check (
    student_status is null or student_status in ('student', 'former_student', 'not_student')
  ),
  apprenticeship_status text check (
    apprenticeship_status is null or apprenticeship_status in ('apprentice', 'searching', 'not_applicable')
  ),
  administrative_status text check (
    administrative_status is null or administrative_status in (
      'eu_citizen',
      'student_residence_permit',
      'other_residence_permit',
      'visa',
      'other'
    )
  ),
  residence_document_type text check (
    residence_document_type is null or char_length(residence_document_type) <= 120
  ),
  residence_document_expiry date,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

comment on table public.profiles is
  'Profil NDF CONNECT privé, rattaché exactement à un utilisateur Supabase Auth.';

create or replace function public.set_updated_at()
returns trigger
language plpgsql
security invoker
set search_path = ''
as $$
begin
  new.updated_at = timezone('utc', now());
  return new;
end;
$$;

create trigger profiles_set_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, first_name, last_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'first_name', ''),
    coalesce(new.raw_user_meta_data ->> 'last_name', '')
  );
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.profiles force row level security;

revoke all on table public.profiles from anon;
grant select, insert, update on table public.profiles to authenticated;

create policy "profiles_select_own"
on public.profiles
for select
to authenticated
using ((select auth.uid()) = id);

create policy "profiles_insert_own"
on public.profiles
for insert
to authenticated
with check ((select auth.uid()) = id);

create policy "profiles_update_own"
on public.profiles
for update
to authenticated
using ((select auth.uid()) = id)
with check ((select auth.uid()) = id);
