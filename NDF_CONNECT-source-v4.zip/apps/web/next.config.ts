import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  basePath: "/NDF_Connect",
  devIndicators: false,
  output: "export",
  reactStrictMode: true,
  transpilePackages: ["@ndf-connect/shared"],
};

export default nextConfig;
